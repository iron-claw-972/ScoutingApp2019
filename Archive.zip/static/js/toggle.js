function toggle() {
    document.getElementById("background").style.backgroundImage = 'url("../images/toggle/scoutingLogo.png")';
    document.getElementById("toggle").style.display = "none";
}